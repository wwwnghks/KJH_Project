package com.bitcamp.persistence;

import com.bitcamp.domain.Member;


public interface MemberDAO {

	public int insert(Member member);

	public Member login(Member member);


}
