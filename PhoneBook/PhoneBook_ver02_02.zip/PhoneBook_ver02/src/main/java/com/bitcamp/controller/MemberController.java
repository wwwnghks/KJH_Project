package com.bitcamp.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bitcamp.domain.Member;
import com.bitcamp.service.MemberService;

@Controller
public class MemberController {


	@Inject
	private MemberService service;

	@RequestMapping(value = "/member/memberReg", method = RequestMethod.GET)
	public String reg() {
		return "member/memberReg";
	}

	@RequestMapping(value = "/", method = RequestMethod.POST)
	public String regsuccess(Member member,HttpServletRequest request) throws Exception {
		int result = service.insert(member,request);
		if (result != 0) {
			return "home";
		}
		return "regFail";
	}
}
