package com.bitcamp.persistence;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.bitcamp.domain.Member;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;

@Repository
public class PhoneBookReadDAOImpl implements PhoneBookReadDAO {
	
	@Inject
	private SqlSession session;

	private static String namespace="com.bitcamp.mapper.PhoneBookMapper";
	
	@Override
	public List<PhoneInfo_Univ> uni_select(Member member) {
		// TODO Auto-generated method stub
		List<PhoneInfo_Univ> uni_list = session.selectList(namespace+".uni_select", member);
		return uni_list;
	}

	@Override
	public List<PhoneInfo_Com> com_select(Member member) {
		// TODO Auto-generated method stub
		List<PhoneInfo_Com> com_list = session.selectList(namespace+".com_select", member);
		return com_list;
	}

	@Override
	public PhoneInfo_Univ uni_selectOne(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		PhoneInfo_Univ result = session.selectOne(namespace+".uni_selectOne", phoneInfo_Basic);
		return result;
	}

	@Override
	public PhoneInfo_Com com_selectOne(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		PhoneInfo_Com result = session.selectOne(namespace+".com_selectOne", phoneInfo_Basic);
		return result;
	}

	

}
