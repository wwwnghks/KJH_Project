package com.bitcamp.service;


import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;

public interface PhoneBookUpdateService {
	
	public void uni_modify(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Univ phoneInfo_Univ);
	
	public void com_modify(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Com phoneInfo_Com);

}
