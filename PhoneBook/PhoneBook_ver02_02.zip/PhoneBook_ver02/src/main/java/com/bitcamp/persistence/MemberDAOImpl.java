package com.bitcamp.persistence;



import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.bitcamp.domain.Member;


@Repository
public class MemberDAOImpl implements MemberDAO{

	
	
	@Inject
	private SqlSession session;
	

	private static String namespace="com.bitcamp.mapper.MemberMapper";
	
	@Override
	public int insert(Member member) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".insert",member);
	}

	@Override
	public Member login(Member member) {
		// TODO Auto-generated method stub
		Member result=session.selectOne(namespace+".login",member);
		
		return result;
	}



}
