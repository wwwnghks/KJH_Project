package com.bitcamp.service;

import java.util.List;

import com.bitcamp.domain.Member;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;

public interface PhoneBookReadService {
	
	public List<PhoneInfo_Univ> uni_select(Member member);

	public List<PhoneInfo_Com> com_select(Member member);

	public PhoneInfo_Univ uni_selectOne(PhoneInfo_Basic phoneInfo_Basic);

	public PhoneInfo_Com com_selectOne(PhoneInfo_Basic phoneInfo_Com);

}
