package com.bitcamp.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;
import com.bitcamp.service.PhoneBookCreateService;


@Controller
public class PhoneBookCreateController {

	@Inject
	private PhoneBookCreateService service;
	
	//URL의 값에 따른 회사 또는 대학 친구 값 넣고 mypage로 이동
	@RequestMapping(value = "/phonebook/mypage2", method = RequestMethod.POST)
	public String mypage2_Post(@RequestParam("key") String key,PhoneInfo_Univ phoneInfo_Univ,PhoneInfo_Basic phoneInfo_Basic ,PhoneInfo_Com phoneInfo_Com) {
		if(key.equals("uni")) {
			service.insert_uni(phoneInfo_Basic,phoneInfo_Univ);
		}else if(key.equals("com")) {
			service.insert_com(phoneInfo_Basic,phoneInfo_Com);
		}
		return "phonebook/mypage";
	}
}
