package com.bitcamp.persistence;


import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;

//PhoneBook 수정 DAO 클래스
@Repository
public class PhoneBookUpdateDAOImpl implements PhoneBookUpdateDAO {
	
	@Inject
	private SqlSession session;

	private static String namespace="com.bitcamp.mapper.PhoneBookMapper";
	
	//대학친구 수정
	@Override
	public void uni_modify(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Univ phoneInfo_Univ) {
		// TODO Auto-generated method stub
		session.update(namespace+".basic_update", phoneInfo_Basic);
		phoneInfo_Univ.setFr_ref(phoneInfo_Basic.getIdx());
		session.update(namespace+".uni_update",phoneInfo_Univ);
	}

	//회사친구 수정
	@Override
	public void com_modify(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Com phoneInfo_Com) {
		// TODO Auto-generated method stub
		session.update(namespace+".basic_update", phoneInfo_Basic);
		phoneInfo_Com.setFr_ref(phoneInfo_Basic.getIdx());
		session.update(namespace+".com_update",phoneInfo_Com);
	}
	

}
