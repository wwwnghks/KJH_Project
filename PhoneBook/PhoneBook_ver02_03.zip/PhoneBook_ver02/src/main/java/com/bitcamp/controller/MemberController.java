package com.bitcamp.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bitcamp.domain.Member;
import com.bitcamp.service.MemberService;

@Controller
public class MemberController {


	@Inject
	private MemberService service;
	
	//회원등록페이지로 이동
	@RequestMapping(value = "/member/memberReg", method = RequestMethod.GET)
	public String reg() {
		return "member/memberReg";
	}

	//회원등록 성공시 홈페이지로 이동, 실패시 regFail페이지로 이동
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public String regsuccess(Member member,HttpServletRequest request) throws Exception {
		int result = service.insert(member,request);
		if (result != 0) {
			return "home";
		}
		return "regFail";
	}
}
