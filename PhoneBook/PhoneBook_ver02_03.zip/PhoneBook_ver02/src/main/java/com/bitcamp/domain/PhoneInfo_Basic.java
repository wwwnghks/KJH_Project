package com.bitcamp.domain;

import java.util.Date;

//친구 기본정보DTO
public class PhoneInfo_Basic {
	private int idx;
	private String fr_name;
	private String fr_phone;
	private String fr_email;
	private String fr_address;
	private Date fr_regdate;
	private String fr_ref_idx;
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getFr_name() {
		return fr_name;
	}
	public void setFr_name(String fr_name) {
		this.fr_name = fr_name;
	}

	public String getFr_email() {
		return fr_email;
	}
	public void setFr_email(String fr_email) {
		this.fr_email = fr_email;
	}
	public String getFr_address() {
		return fr_address;
	}
	public void setFr_address(String fr_address) {
		this.fr_address = fr_address;
	}
	public Date getFr_regdate() {
		return fr_regdate;
	}
	public void setFr_regdate(Date fr_regdate) {
		this.fr_regdate = fr_regdate;
	}

	
	public String getFr_phone() {
		return fr_phone;
	}
	public void setFr_phone(String fr_phone) {
		this.fr_phone = fr_phone;
	}
	public String getFr_ref_idx() {
		return fr_ref_idx;
	}
	public void setFr_ref_idx(String fr_ref_idx) {
		this.fr_ref_idx = fr_ref_idx;
	}
	
	
	@Override
	public String toString() {
		return "PhoneInfo_Basic [idx=" + idx + ", fr_name=" + fr_name + ", fr_phone=" + fr_phone + ", fr_email="
				+ fr_email + ", fr_address=" + fr_address + ", fr_regdate=" + fr_regdate + ", fr_ref_idx=" + fr_ref_idx
				+ "]";
	}
	public PhoneInfo_Basic(int idx, String fr_name, String fr_phone, String fr_email, String fr_address,
			Date fr_regdate, String fr_ref_idx) {
		super();
		this.idx = idx;
		this.fr_name = fr_name;
		this.fr_phone = fr_phone;
		this.fr_email = fr_email;
		this.fr_address = fr_address;
		this.fr_regdate = fr_regdate;
		this.fr_ref_idx = fr_ref_idx;
	}
	public PhoneInfo_Basic() {
		super();
	}

	
	
}
