package com.bitcamp.service;



import javax.servlet.http.HttpServletRequest;
import com.bitcamp.domain.Member;

//회원 Service 인터페이스
public interface MemberService {

	public int insert(Member member,HttpServletRequest request) throws Exception;

	public Member login(Member member);


}
