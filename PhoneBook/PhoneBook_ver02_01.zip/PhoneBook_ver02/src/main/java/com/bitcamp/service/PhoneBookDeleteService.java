package com.bitcamp.service;


import com.bitcamp.domain.PhoneInfo_Basic;


public interface PhoneBookDeleteService {
	public void com_delete(PhoneInfo_Basic phoneInfo_Basic);

	public void uni_delete(PhoneInfo_Basic phoneInfo_Basic);

}
