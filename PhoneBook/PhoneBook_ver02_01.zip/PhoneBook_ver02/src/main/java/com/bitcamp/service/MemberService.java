package com.bitcamp.service;



import javax.servlet.http.HttpServletRequest;
import com.bitcamp.domain.Member;

public interface MemberService {

	public int insert(Member member,HttpServletRequest request) throws Exception;

	public Member login(Member member);


}
