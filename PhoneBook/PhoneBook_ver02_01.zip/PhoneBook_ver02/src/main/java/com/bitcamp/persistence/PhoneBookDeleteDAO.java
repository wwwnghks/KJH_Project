package com.bitcamp.persistence;

import com.bitcamp.domain.PhoneInfo_Basic;

public interface PhoneBookDeleteDAO {

	public void com_delete(PhoneInfo_Basic phoneInfo_Basic);

	public void uni_delete(PhoneInfo_Basic phoneInfo_Basic);

}
