package com.bitcamp.controller;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.bitcamp.domain.Member;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;
import com.bitcamp.service.PhoneBookReadService;


@Controller
public class PhoneBookReadController {

	@Inject
	private PhoneBookReadService service;
	
	@RequestMapping(value = "/phonebook/all")
	 public String all(Model model,Member member) {
		 List<PhoneInfo_Univ> uni_list = service.uni_select(member);
		 List<PhoneInfo_Com> com_list = service.com_select(member);
		 model.addAttribute("uni_list", uni_list);
		 model.addAttribute("com_list", com_list);

	 return "phonebook/all";
	 }
	
	@RequestMapping(value="/phonebook/fr_info",method=RequestMethod.GET)
	public String fr_info(@RequestParam("phone") String phone,PhoneInfo_Basic phoneInfo_Basic,PhoneInfo_Univ phoneInfo_Univ,PhoneInfo_Com phoneInfo_Com,@RequestParam("fr") String fr,Model model) {
		
		if(fr.equals("uni")) {
			phoneInfo_Basic.setFr_phone(phone);
			PhoneInfo_Univ fr_uni=service.uni_selectOne(phoneInfo_Basic);
			model.addAttribute("fr_uni", fr_uni);
			return "phonebook/uni_info";
		}else if(fr.equals("com")) {
			phoneInfo_Basic.setFr_phone(phone);
			PhoneInfo_Com fr_com=service.com_selectOne(phoneInfo_Basic);
			model.addAttribute("fr_com",fr_com);
			return "phonebook/com_info";
		}
		return "phonebook/mypage";
	}
}
