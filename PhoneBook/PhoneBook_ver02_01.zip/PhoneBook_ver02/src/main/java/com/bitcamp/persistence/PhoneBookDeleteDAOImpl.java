package com.bitcamp.persistence;



import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.bitcamp.domain.PhoneInfo_Basic;


@Repository
public class PhoneBookDeleteDAOImpl implements PhoneBookDeleteDAO {
	
	@Inject
	private SqlSession session;

	private static String namespace="com.bitcamp.mapper.PhoneBookMapper";
	
	@Override
	public void com_delete(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		session.delete(namespace+".com_delete", phoneInfo_Basic);
	}

	@Override
	public void uni_delete(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		session.delete(namespace+".uni_delete", phoneInfo_Basic);
	}

}
