package com.bitcamp.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.service.PhoneBookDeleteService;


@Controller
public class PhoneBookDeleteController {

	@Inject
	private PhoneBookDeleteService service;
	
	@RequestMapping(value="/phonebook/com_delete",method=RequestMethod.POST)
	public String com_delete(PhoneInfo_Basic phoneInfo_Basic) {
		service.com_delete(phoneInfo_Basic);
		return "phonebook/mypage";
	}
	
	@RequestMapping(value="/phonebook/uni_delete",method=RequestMethod.POST)
	public String uni_delete(PhoneInfo_Basic phoneInfo_Basic) {
		service.uni_delete(phoneInfo_Basic);
		return "phonebook/mypage";
	}
}
