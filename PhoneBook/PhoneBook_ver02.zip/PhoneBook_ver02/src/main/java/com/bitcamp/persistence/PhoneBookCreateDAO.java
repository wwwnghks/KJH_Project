package com.bitcamp.persistence;

import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;

public interface PhoneBookCreateDAO {
	
	public void insert_uni(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Univ phoneInfo_Univ);

	public void insert_com(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Com phoneInfo_Com);
}
