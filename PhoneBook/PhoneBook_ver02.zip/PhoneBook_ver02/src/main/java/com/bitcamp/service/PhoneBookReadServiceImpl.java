package com.bitcamp.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.bitcamp.domain.Member;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;
import com.bitcamp.persistence.PhoneBookReadDAO;

@Service
public class PhoneBookReadServiceImpl implements PhoneBookReadService {
	
	@Inject
	private PhoneBookReadDAO dao;

	@Override
	public List<PhoneInfo_Univ> uni_select(Member member) {
		// TODO Auto-generated method stub
		List<PhoneInfo_Univ> uni_list = dao.uni_select(member);
		return uni_list;
	}

	@Override
	public List<PhoneInfo_Com> com_select(Member member) {
		// TODO Auto-generated method stub
		List<PhoneInfo_Com> com_list = dao.com_select(member);
		return com_list;
	}

	@Override
	public PhoneInfo_Univ uni_selectOne(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		PhoneInfo_Univ result = dao.uni_selectOne(phoneInfo_Basic);
		return result;
	}

	@Override
	public PhoneInfo_Com com_selectOne(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		PhoneInfo_Com result = dao.com_selectOne(phoneInfo_Basic);
		return result;
	}

}
