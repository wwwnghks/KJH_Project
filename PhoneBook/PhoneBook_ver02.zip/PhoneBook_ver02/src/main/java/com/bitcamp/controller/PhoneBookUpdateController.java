package com.bitcamp.controller;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;
import com.bitcamp.service.PhoneBookUpdateService;

@Controller
public class PhoneBookUpdateController {

	@Inject
	private PhoneBookUpdateService service;
	
	@RequestMapping(value="/phonebook/com_modify",method=RequestMethod.GET)
	public String com_modifyGET(Model model,PhoneInfo_Com phoneInfo_Com) {
		model.addAttribute("fr_com", phoneInfo_Com);
		return "phonebook/com_modify";
	}
	
	@RequestMapping(value="/phonebook/com_modify",method=RequestMethod.POST)
	public String com_modifyPOST(PhoneInfo_Basic phoneInfo_Basic,PhoneInfo_Com phoneInfo_Com) {
		service.com_modify(phoneInfo_Basic, phoneInfo_Com);
		return "phonebook/mypage";
	}
	
	@RequestMapping(value="/phonebook/uni_modify",method=RequestMethod.GET)
	public String uni_modifyGET(Model model,PhoneInfo_Univ phoneInfo_Univ) {
		model.addAttribute("fr_uni", phoneInfo_Univ);
		return "phonebook/uni_modify";
	}
	
	@RequestMapping(value="/phonebook/uni_modify",method=RequestMethod.POST)
	public String uni_modifyPOST(Model model,PhoneInfo_Basic phoneInfo_Basic,PhoneInfo_Univ phoneInfo_Univ) {
		service.uni_modify(phoneInfo_Basic,phoneInfo_Univ);
		return "phonebook/mypage";
	}
}
