package com.bitcamp.controller;


import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.bitcamp.domain.Member;
import com.bitcamp.service.MemberService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	

	
	@Inject
	private MemberService memberservice;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpSession session) {
		session.invalidate();
		return "home";
	}
	
	@RequestMapping(value = "/phonebook/mypage", method = RequestMethod.POST)
	public String login(Member member, HttpSession session, Model model) {

		Member result = memberservice.login(member);

		if (result == null) {
			return "redirect:/";
		} else {
			session.setAttribute("member", result);
			model.addAttribute("member", session.getAttribute("member"));
			return "phonebook/mypage";
		}
	}
}
