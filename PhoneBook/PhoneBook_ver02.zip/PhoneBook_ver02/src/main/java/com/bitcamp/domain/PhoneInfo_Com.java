package com.bitcamp.domain;

public class PhoneInfo_Com extends PhoneInfo_Basic{
	private int idx;
	private String fr_c_company;
	private int fr_ref;

	public PhoneInfo_Com(int idx, String fr_c_company, int fr_ref) {
		super();
		this.idx = idx;
		this.fr_c_company = fr_c_company;
		this.fr_ref = fr_ref;
	}
	
	public String getFr_c_company() {
		return fr_c_company;
	}

	public void setFr_c_company(String fr_c_company) {
		this.fr_c_company = fr_c_company;
	}

	public PhoneInfo_Com() {
		super();
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	
	public int getFr_ref() {
		return fr_ref;
	}
	public void setFr_ref(int fr_ref) {
		this.fr_ref = fr_ref;
	}
	@Override
	public String toString() {
		return "PhoneInfo_Com [idx=" + idx + ", fr_c_company=" + fr_c_company + ", fr_ref=" + fr_ref + "]";
	}
	
	
	
	
}
