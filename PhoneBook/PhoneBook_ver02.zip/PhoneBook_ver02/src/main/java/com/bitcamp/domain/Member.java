package com.bitcamp.domain;

import java.io.Serializable;
import java.util.Date;

import org.springframework.web.multipart.MultipartFile;

public class Member implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */

	private int idx;
	private String id;
	private String password;
	private String name;
	private Date regdate;
	private MultipartFile photofile;
	private String photo;
	
	
	@Override
	public String toString() {
		return "Member [idx=" + idx + ", id=" + id + ", password=" + password + ", name=" + name + ", regdate="
				+ regdate + ", photofile=" + photofile + ", photo=" + photo + "]";
	}
	public Member(int idx, String id, String password, String name, Date regdate, MultipartFile photofile,
			String photo) {
		super();
		this.idx = idx;
		this.id = id;
		this.password = password;
		this.name = name;
		this.regdate = regdate;
		this.photofile = photofile;
		this.photo = photo;
	}
	public MultipartFile getPhotofile() {
		return photofile;
	}
	public void setPhotofile(MultipartFile photofile) {
		this.photofile = photofile;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public int getIdx() {
		return idx;
	}
	public void setIdx(int idx) {
		this.idx = idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getRegdate() {
		return regdate;
	}
	public void setRegdate(Date regdate) {
		this.regdate = regdate;
	}

	public Member() {
		super();
	}

	
}
