package com.bitcamp.controller;




import javax.servlet.http.HttpSession;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.bitcamp.domain.Member;


@Controller
public class PhoneBookController {

	@RequestMapping(value = "/phonebook/mypage", method = RequestMethod.GET)
	public String mypage(Member member, HttpSession session, Model model) {
		if(session.getAttribute("member")!=null) {
			model.addAttribute("member", session.getAttribute("member"));
			return "phonebook/mypage";
		}else {
			return "home";
		}
	}

	@RequestMapping(value = "/phonebook/mypage2", method = RequestMethod.GET)
	public String mypage2_Get(@RequestParam("key") String key, Model model) {
		model.addAttribute("result", key);
		return "phonebook/mypage";
	}
	
	@RequestMapping(value = "/phonebook/com")
	public String com() {
		return "phonebook/com";
	}

	@RequestMapping(value = "/phonebook/uni")
	public String uni() {
		return "phonebook/uni";
	}
}
