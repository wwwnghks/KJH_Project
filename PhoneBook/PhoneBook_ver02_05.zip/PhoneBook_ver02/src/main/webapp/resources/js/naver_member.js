$(function(){
	var id = document.getElementById('email').innerHTML;
	var name = document.getElementById('name').innerHTML;
	alert(id+' : '+ name);
	$.ajax({
		data : {
			"id" : id,
			"password" : "naver",
			"name" : name
		},
		method : 'get'
		,
		url : "naver_log",
		dataType : 'json',
		success : function(data) {
			alert(data.result);
		},
		error : function(request, status, error) {
			alert("code:" + request.status + "\n" + "error:" + error);
		}
	});
})