package com.bitcamp.service;



import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;
import com.bitcamp.persistence.PhoneBookCreateDAO;

//PhoneBook 저장 Service 클래스
@Service
public class PhoneBookCreateServiceImpl implements PhoneBookCreateService {
	
	@Inject
	private PhoneBookCreateDAO dao;

	//대학친구 저장
	@Override
	public void insert_uni(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Univ phoneInfo_Univ) {
		dao.insert_uni(phoneInfo_Basic,phoneInfo_Univ);
		
	}
	//회사친구 저장
	@Override
	public void insert_com(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Com phoneInfo_Com) {
		// TODO Auto-generated method stub
		dao.insert_com(phoneInfo_Basic,phoneInfo_Com);
	}
}
