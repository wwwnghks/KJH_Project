package com.bitcamp.service;

import javax.inject.Inject;
import org.springframework.stereotype.Service;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.persistence.PhoneBookDeleteDAO;

//PhoneBook 삭제 Service 클래스
@Service
public class PhoneBookDeleteServiceImpl implements PhoneBookDeleteService {
	
	@Inject
	private PhoneBookDeleteDAO dao;
	
	//회사친구 삭제
	@Override
	public void com_delete(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		dao.com_delete(phoneInfo_Basic);
	}

	//대학친구 삭제
	@Override
	public void uni_delete(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		dao.uni_delete(phoneInfo_Basic);
	}

}
