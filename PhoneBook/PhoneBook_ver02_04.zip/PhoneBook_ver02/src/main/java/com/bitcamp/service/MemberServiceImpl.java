package com.bitcamp.service;

import java.io.File;


import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Service;

import com.bitcamp.domain.Member;
import com.bitcamp.persistence.MemberDAO;

//회원 Service
@Service
public class MemberServiceImpl implements MemberService{

	@Inject
	private MemberDAO dao;
	
	//회원 등록
	@Override
	public int insert(Member member,HttpServletRequest request) throws Exception {
		// TODO Auto-generated method stub
		String uploadURI = "/uploadfile/memberphoto";
		String dir = request.getSession().getServletContext().getRealPath(uploadURI);
		System.out.println(dir);

		// 업로드 파일의 물리적 저장
		// 파일 저장 : 증명사진.jpg
		// 회원의 사진은 하나만 존재한다.
		// 파일 이름 생성 : 회원아이디_원본파일이름
		if (!member.getPhotofile().isEmpty()) {
			// 새로운 파일 이름 생성 -> 파일 저장 -> DB에 저장할 파일이름 set
			String fileName = member.getId() + "_" + member.getPhotofile().getOriginalFilename();
			member.getPhotofile().transferTo(new File(dir, fileName));
			member.setPhoto(fileName);
		}

		// 업로드한 파일의 데이터를 Member에 등록
		// dao 요청 : 데이터 저장 요청
		int result = dao.insert(member);
		return result;
	}
	//회원 로그인
	@Override
	public Member login(Member member) {
		// TODO Auto-generated method stub
		Member result = dao.login(member);
		
		return result;
	}
	@Override
	public int id_check(Member member) {
		// TODO Auto-generated method stub
		return dao.id_check(member);
	}



}
