package com.bitcamp.persistence;

import com.bitcamp.domain.Member;

//회원 DAO 인터페이스
public interface MemberDAO {
	
	public int insert(Member member);

	public Member login(Member member);
	
	public int id_check(Member member);


}
