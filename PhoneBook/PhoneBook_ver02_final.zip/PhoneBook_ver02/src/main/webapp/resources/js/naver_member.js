$(function(){
	var id = document.getElementById('email').innerHTML;
	var name = document.getElementById('name').innerHTML;
	$.ajax({
		data : {
			"id" : id,
			"password" : "naver",
			"name" : name
		},
		method : 'get'
		,
		url : "../member/naver_member",
		dataType : 'json',
		error : function(request, status, error) {
			alert("code:" + request.status + "\n" + "error:" + error);
		}
	});
})