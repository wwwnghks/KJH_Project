package com.bitcamp.controller;


import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.bitcamp.domain.Member;


@Controller
public class PhoneBookController {


	// 세션 정보 있을시 mypage로 없으면 홈페이지로 이동
	@RequestMapping(value = "/phonebook/mypage", method = RequestMethod.GET)
	public String mypage(Member member, HttpSession session, Model model) {
		if (session.getAttribute("member") != null) {
			model.addAttribute("member", session.getAttribute("member"));
			return "phonebook/mypage";
		} else {
			return "redirect:/";
		}
	}

	// a태그의 값에 따른 mypage2로 이동
	@RequestMapping(value = "/phonebook/mypage2", method = RequestMethod.GET)
	public String mypage2_Get(@RequestParam("key") String key, Model model) {
		model.addAttribute("result", key);
		return "phonebook/mypage";
	}

	
	
	
	// 회사친구 등록 페이지 이동
	@RequestMapping(value = "/phonebook/com")
	public String com() {
		return "phonebook/com";
	}

	// 대학친구 등록페이지 이동
	@RequestMapping(value = "/phonebook/uni")
	public String uni() {
		return "phonebook/uni";
	}
}
