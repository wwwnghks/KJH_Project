package com.bitcamp.service;



import javax.servlet.http.HttpServletRequest;
import com.bitcamp.domain.Member;

//회원 Service 인터페이스
public interface MemberService {

	public int insert(Member member,HttpServletRequest request) throws Exception;
	
	//public Member session_info(Member member);
	
	public int naver_insert(Member member);
	
	public Member login(Member member);
	
	public int id_check(Member member);
	
	


}
