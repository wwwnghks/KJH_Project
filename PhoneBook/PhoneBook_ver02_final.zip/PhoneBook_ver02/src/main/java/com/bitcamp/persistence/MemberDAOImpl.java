package com.bitcamp.persistence;



import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.bitcamp.domain.Member;

//회원 DAO 클래스
@Repository
public class MemberDAOImpl implements MemberDAO{

	
	
	@Inject
	private SqlSession session;
	

	private static String namespace="com.bitcamp.mapper.MemberMapper";
	
	//회원 등록
	@Override
	public int insert(Member member) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".insert",member);
	}
	
	//로그인 
	@Override
	public Member login(Member member) {
		// TODO Auto-generated method stub
		Member result=session.selectOne(namespace+".login",member);
		
		return result;
	}

	@Override
	public int id_check(Member member) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".id_check", member);
	}

	@Override
	public int naver_insert(Member member) {
		// TODO Auto-generated method stub
		return session.insert(namespace+".naver_insert",member);
	}

//	@Override
//	public Member session_info(Member member) {
//		// TODO Auto-generated method stub
//		return session.selectOne(namespace+".session_info", member);
//	}



}
