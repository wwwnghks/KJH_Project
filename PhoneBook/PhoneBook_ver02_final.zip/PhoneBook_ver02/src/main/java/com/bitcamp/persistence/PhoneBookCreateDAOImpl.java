package com.bitcamp.persistence;


import javax.inject.Inject;
import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;

//PhoneBook 저장 DAO 클래스
@Repository
public class PhoneBookCreateDAOImpl implements PhoneBookCreateDAO {

	@Inject
	private SqlSession session;

	private static String namespace="com.bitcamp.mapper.PhoneBookMapper";
	
	//대학친구 저장
	@Override
	public void insert_uni(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Univ phoneInfo_Univ) {
		// TODO Auto-generated method stub
		session.insert(namespace+".basic_insert", phoneInfo_Basic);
		phoneInfo_Univ.setFr_ref(phoneInfo_Basic.getIdx());
		session.insert(namespace+".univ_insert",phoneInfo_Univ);
	}

	//회사친구 저장
	@Override
	public void insert_com(PhoneInfo_Basic phoneInfo_Basic, PhoneInfo_Com phoneInfo_Com) {
		// TODO Auto-generated method stub
		session.insert(namespace+".basic_insert", phoneInfo_Basic);
		phoneInfo_Com.setFr_ref(phoneInfo_Basic.getIdx());
		session.insert(namespace+".com_insert",phoneInfo_Com);
	}
	
	

}
