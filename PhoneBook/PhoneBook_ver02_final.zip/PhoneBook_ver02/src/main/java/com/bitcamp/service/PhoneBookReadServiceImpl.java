package com.bitcamp.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.bitcamp.domain.Member;
import com.bitcamp.domain.PhoneInfo_Basic;
import com.bitcamp.domain.PhoneInfo_Com;
import com.bitcamp.domain.PhoneInfo_Univ;
import com.bitcamp.persistence.PhoneBookReadDAO;

//PhoneBook 값가져오기 Service 클래스
@Service
public class PhoneBookReadServiceImpl implements PhoneBookReadService {
	
	@Inject
	private PhoneBookReadDAO dao;

	//대학친구 모두가져오기 (회원별)
	@Override
	public List<PhoneInfo_Univ> uni_select(Member member) {
		// TODO Auto-generated method stub
		List<PhoneInfo_Univ> uni_list = dao.uni_select(member);
		return uni_list;
	}
	//회사친구 모두가져오기 (회원별)
	@Override
	public List<PhoneInfo_Com> com_select(Member member) {
		// TODO Auto-generated method stub
		List<PhoneInfo_Com> com_list = dao.com_select(member);
		return com_list;
	}
	//대학친구 한명 가져오기
	@Override
	public PhoneInfo_Univ uni_selectOne(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		PhoneInfo_Univ result = dao.uni_selectOne(phoneInfo_Basic);
		return result;
	}
	//회사친구 한명 가져오기
	@Override
	public PhoneInfo_Com com_selectOne(PhoneInfo_Basic phoneInfo_Basic) {
		// TODO Auto-generated method stub
		PhoneInfo_Com result = dao.com_selectOne(phoneInfo_Basic);
		return result;
	}

}
