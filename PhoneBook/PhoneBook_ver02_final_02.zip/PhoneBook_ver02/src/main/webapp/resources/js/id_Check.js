/*ajax를 이용한 json으로 정보 주고받기*/
var idCheck = 0;
	function id_check() {
		var inputed = $('#id').val();
		$.ajax({
			data : {
				"id" : inputed
			},
			url : "checkId",
			dataType : 'json',
			success : function(data) {
				if (data.result == "length") {
					$('#logCh').html("8자 이상 입력하세요.");
					$('#logCh').css('color', 'red');
					$('#reg_btn').attr('disabled', 'disabled');
				} else {
					if (data.result == "true") {
						$('#logCh').html("사용 불가능한 아이디입니다.");
						$('#logCh').css('color', 'red');
						$('#reg_btn').attr('disabled', 'disabled');
					} else {
						$('#logCh').html("사용 가능한 아이디입니다.");
						$('#logCh').css('color', 'blue');
						$('#reg_btn').removeAttr('disabled');
					}
				}
			},
			error : function(request, status, error) {
				alert("code:" + request.status + "\n" + "error:" + error);
			}
		});
	}
