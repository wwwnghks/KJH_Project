package com.bitcamp.controller;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.bitcamp.domain.Member;
import com.bitcamp.naver.NaverLoginBO;
import com.bitcamp.service.MemberService;
import com.github.scribejava.core.model.OAuth2AccessToken;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private NaverLoginBO naverLoginBO;
	private String apiResult = null;

	@Autowired
	private void setNaverLoginBO(NaverLoginBO naverLoginBO) {
		this.naverLoginBO = naverLoginBO;
	}

	@Inject
	private MemberService memberservice;

	/**
	 * Simply selects the home view to render by returning its name.
	 */

	// 홈페이지 이동
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpSession session,Model model) {
		String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
		// 네이버
		model.addAttribute("url", naverAuthUrl);
		return "home";
	}
	
	//로그아웃
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session,Model model) {
		session.invalidate();
		return "redirect:/";
	}

	//네이버페이지로 이동
	@RequestMapping(value = "/phonebook/naver_mypage", method = { RequestMethod.GET})
	public String naver_mypage(Model model, @RequestParam String code, @RequestParam String state, HttpSession session)
			throws IOException {
		OAuth2AccessToken oauthToken;
        oauthToken = naverLoginBO.getAccessToken(session, code, state);
        //로그인 사용자 정보를 읽어온다
	    apiResult = naverLoginBO.getUserProfile(oauthToken);
		model.addAttribute("naver", apiResult);
		
        /* 네이버 로그인 성공 페이지 View 호출 */
		return "phonebook/mypage";
	}
	
	// 로그인 성공시 mypage로,실패시 홈페이지로 이동
	@RequestMapping(value = "/phonebook/mypage", method = RequestMethod.POST)
	public String login(Member member, HttpSession session, Model model) {
		Member result = memberservice.login(member);
		if (result == null) {
			return "redirect:/";
		} else {
			session.setAttribute("member", result);
			model.addAttribute("member", session.getAttribute("member"));
			return "phonebook/mypage";
		}
	}

}
