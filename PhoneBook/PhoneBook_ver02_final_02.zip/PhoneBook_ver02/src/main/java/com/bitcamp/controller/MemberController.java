package com.bitcamp.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bitcamp.domain.Member;
import com.bitcamp.service.MemberService;

@Controller
public class MemberController {

	@Inject
	private MemberService service;

	// 회원등록페이지로 이동
	@RequestMapping(value = "/member/memberReg", method = RequestMethod.GET)
	public String reg() {
		return "member/memberReg";
	}

	// 네이버 로그인 후 자동으로 회원db에 저장
	@RequestMapping(value = "/member/naver_member", method = RequestMethod.GET)
	@ResponseBody
	public String naver_newMember(@RequestParam("id") String id, @RequestParam("password") String password,
			@RequestParam("name") String name, Model model, HttpSession session) {
		Member naver_newMember = new Member();
		naver_newMember.setId(id);
		naver_newMember.setPassword(password);
		naver_newMember.setName(name);
		if (session.getAttribute("member") == null) {
			Member s_member = service.login(naver_newMember);
			session.setAttribute("member", s_member);
		}
		if (service.id_check(naver_newMember) == 0 && !id.equals("")) {
			service.naver_insert(naver_newMember);
			return "{\"result\":\"" + "naver_newmember\"}";
		} else {
			return "{\"result\":\"" + "nonononono\"}";
		}

	}

	// 회원등록 성공시 홈페이지로 이동, 실패시 regFail페이지로 이동
	@RequestMapping(value = "/", method = RequestMethod.POST)
	public String regsuccess(Member member, HttpServletRequest request) throws Exception {
		int result = service.insert(member, request);
		if (result != 0) {
			return "home";
		}
		return "regFail";
	}

	// 회원가입의 id 길이와 존재여부 판단
	@RequestMapping(value = "/member/checkId", method = RequestMethod.GET)
	@ResponseBody
	public String idCheck(@RequestParam("id") String id, Model model) {
		Member ajax_member = new Member();
		ajax_member.setId(id);
		int result = service.id_check(ajax_member);
		if (id.length() < 8) {
			model.addAttribute("result", "length");
			return "{\"result\":\"" + "length\"}";
		} else {
			if (result != 0) {
				model.addAttribute("result", "true");
				return "{\"result\":\"" + "true\"}";
			} else {
				model.addAttribute("result", "false");
				return "{\"result\":\"" + "false\"}";
			}
		}
	}
}
